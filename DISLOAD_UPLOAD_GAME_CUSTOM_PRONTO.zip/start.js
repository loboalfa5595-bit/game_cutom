// start.js — Wrapper GAME CUSTOM v3 (com env.txt -> .env auto)
// 0) GAMBIARRA CRÍTICA: Discloud apaga arquivos que começam com '.' após upload ZIP:
//    se existir env.txt mas NÃO existir .env → renomeia env.txt para .env ANTES de qualquer coisa.
// 1) Tenta require INLINE do bundle.js (se der erro na hora do import, a gente pega stack direto)
// 2) Se sucesso no load → spawn o bundle como processo filho para pegar stdout/stderr separado
// 3) Qualquer erro em QUALQUER etapa → gravado PRIMEIRO em bot-startup-log.txt, antes de morrer.
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const LOG_FILE = path.join(process.cwd(), 'bot-startup-log.txt');
let logStream;
try {
  logStream = fs.createWriteStream(LOG_FILE, { flags: 'a' });
  logStream.on('error', function(){});
} catch(_) {}

function log(msg) {
  const linha = String(msg) + '\n';
  process.stdout.write(linha);
  try { if (logStream && !logStream.destroyed) logStream.write(linha); } catch(_) {}
  try { fs.appendFileSync(LOG_FILE, '[Fsync] ' + linha); } catch(_) {}
}

// Primeira coisa: grava cabeçalho, mesmo que dê erro em seguida
try {
  const agora = new Date().toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' });

  // ====== PASSO 0 (MORTAL) — env.txt -> .env SE PRECISAR ======
  try {
    const temDotEnv = fs.existsSync('.env') && fs.statSync('.env').size > 5;
    const temEnvTxt = fs.existsSync('env.txt') && fs.statSync('env.txt').size > 5;
    if (!temDotEnv && temEnvTxt) {
      fs.copyFileSync('env.txt', '.env');
      if (fs.existsSync('.env') && fs.statSync('.env').size > 5) {
        try { fs.appendFileSync(LOG_FILE, '[ENV FIX] Copiamos env.txt -> .env (Discloud apagou .env na extracao)
'); } catch(_) {}
      }
    } else if (temDotEnv) {
      try { fs.appendFileSync(LOG_FILE, '[ENV OK] .env ja existia (size=' + fs.statSync('.env').size + ' bytes). Nao precisou renomear.
'); } catch(_) {}
    } else {
      try { fs.appendFileSync(LOG_FILE, '[ENV FATAL] NEM .env NEM env.txt EXISTEM! DISCORD_TOKEN VAI FALTAR.
'); } catch(_) {}
    }
  } catch(e) {
    try { fs.appendFileSync(LOG_FILE, '[ENV FIX ERRO] ' + (e && e.stack || e) + '
'); } catch(_) {}
  }
  log('');
  log('==================================================================');
  log('[START v2] ' + agora);
  log('[START] cwd        = ' + process.cwd());
  log('[START] Node       = ' + process.version + ' | arch=' + process.arch + ' | platform=' + process.platform);
  log('[START] PID pai    = ' + process.pid);
  log('[START] NODE_OPT   = ' + (process.env.NODE_OPTIONS || '(vazio)'));
  log('[START] execPath   = ' + process.execPath);
  try {
    const arqs = fs.readdirSync('.').filter(f => !f.startsWith('.')).sort();
    log('[START] arquivos cwd (' + arqs.length + '): ' + arqs.join(', '));
    if (!fs.existsSync('bundle.js')) log('[START ⚠️] bundle.js NÃO EXISTE na raiz! Verifique o upload do ZIP.');
    if (!fs.existsSync('.env')) log('[START ⚠️] .env NÃO EXISTE na raiz! Token vai faltar.');
    if (!fs.existsSync('package.json')) log('[START ⚠️] package.json NÃO EXISTE na raiz!');
    if (!fs.existsSync('discloud.config')) log('[START ⚠️] discloud.config NÃO EXISTE na raiz!');
  } catch(e) { log('[START] erro listar dir: ' + e.message); }

  // Validar Node versão
  const maj = Number(process.version.replace(/^v/, '').split('.')[0]);
  if (maj < 18) { log('[START 🔴] Node ' + process.version + ' muito velho (precisa >= 18.x) — discord.js v14 falha'); }
  if (maj >= 22) { log('[START 🟡] Node ' + process.version + ' >= 22.x (beta) — pode quebrar nativos sql.js. VERSION=20 é recomendado.'); }

  log('==================================================================');
} catch(e) {
  try { fs.appendFileSync(LOG_FILE, '[start.js ERRO inicial] ' + (e && e.stack || e) + '\n'); } catch(_) {}
  process.stdout.write('[start.js] ERRO INICIAL: ' + (e && e.message || e) + '\n');
  process.exit(100);
}

// Catches globais (antes de qualquer coisa)
process.on('uncaughtException', function(e) {
  log('[UNCATCHED EXCEPTION pai] name=' + (e && e.name || '') + ' msg=' + (e && e.message || e));
  if (e && e.stack) log('[STACK] ' + String(e.stack).split(/\r?\n/).slice(0, 12).join('\n[STACK] '));
  try { logStream && logStream.end && logStream.end(); } catch(_) {}
  process.exit(88);
});
process.on('unhandledRejection', function(r, p) {
  log('[UNHANDLED REJECTION pai] reason=' + (r instanceof Error ? (r.name + ': ' + r.message) : String(r)));
});
// SIGTERM recebido da Discloud ao apertar "Parar"
process.on('SIGTERM', () => log('[SIGTERM pai] Recebido. Vou fechar.').slice);

// Tentativa 1 (diagnóstico rápido): tentar CARREGAR bundle.js com require() mas SEM dar login.
// Como o bundle.js hoje tem "dotenv.config() + client.login() mesmo top-level", não podemos require direto.
// Em vez disso, usamos spawn (menos chance de conflito) mas COM log detalhado.
const BUNDLE_PATH = path.join(process.cwd(), 'bundle.js');

if (!fs.existsSync(BUNDLE_PATH)) {
  log('[FATAL 🔴] bundle.js NÃO ENCONTRADO em ' + BUNDLE_PATH + '. Abortando.');
  log('[DICA] Verifique se os arquivos no ZIP estão NA RAIZ (sem pasta DEPLOY_BOT_PRONTO/).');
  process.exit(89);
}

const memAntes = process.memoryUsage();
log('[START] Antes do spawn: RSS=' + Math.round(memAntes.rss / 1048576) + 'MB');
log('[START] Chamando spawn: node bundle.js');

let proc;
try {
  proc = spawn(process.execPath, ['bundle.js'], {
    cwd: process.cwd(),
    env: process.env,
    stdio: ['ignore', 'pipe', 'pipe'],
  });
} catch(e) {
  log('[FATAL 🔴] spawn() lançou erro SÍNCRONO: ' + (e && e.message || e));
  if (e && e.stack) log('[STACK spawn] ' + String(e.stack).split(/\r?\n/).slice(0,10).join('\n[STACK spawn] '));
  process.exit(90);
}

log('[start.js] Processo filho spawnado. PID filho = ' + proc.pid);

proc.stdout.on('data', function(dados){
  const s = String(dados);
  process.stdout.write(s);
  try { logStream.write(s); } catch(_) {}
});
proc.stderr.on('data', function(dados){
  const s = String(dados);
  process.stderr.write(s);
  try { logStream.write('[STDERR] ' + s.replace(/\r?\n/g, '\n[STDERR] ')); } catch(_) {}
});
proc.on('error', function(e) {
  log('[WRAPPER ERROR filho] spawn falhou DEPOIS do retorno: ' + String(e && e.message || e));
  if (e && e.stack) log('[STACK] ' + String(e.stack).split(/\r?\n/).slice(0,10).join('\n[STACK] '));
  try { logStream.end(); } catch(_) {}
  process.exit(101);
});
proc.on('close', function(code, signal) {
  const t = new Date().toLocaleString('pt-BR');
  const memDepois = process.memoryUsage();
  log('[WRAPPER CLOSE ' + t + '] filho codigo=' + code + ' signal=' + signal + ' RSS-pai=' + Math.round(memDepois.rss/1048576) + 'MB');

  // Dicas baseadas no exit code
  if (code === 0) log('[WRAPPER] Filho saiu normalmente.');
  else if (code === 137 || signal === 'SIGKILL') log('[WRAPPER 🔴] Filho foi KILLADO (137/SIGKILL) → PROVÁVEL FALTA DE MEMÓRIA RAM! Aumente RAM ou cheque NODE_OPTIONS.');
  else if (code === 134 || signal === 'SIGABRT') log('[WRAPPER 🔴] SIGABRT → crash nativo (sql.js?) ou memória corrompida.');
  else if (code && code !== 0) log('[WRAPPER 🔴] Filho crashou. Veja as linhas [STDERR] e [FATAL] ACIMA neste log!');

  try { logStream.end(); } catch(_) {}
  process.exit(typeof code === 'number' ? (code === 0 ? 0 : code) : 99);
});

// Heartbeat a cada 15s (mostra que wrapper está vivo mesmo se filho não logar)
let hb = 0;
const heart = setInterval(() => {
  hb++;
  try {
    const mem = process.memoryUsage();
    log('[HB ' + (hb*15) + 's] wrapper vivo. RSS=' + Math.round(mem.rss/1048576) + 'MB | filho vivo=' + (proc && !proc.killed));
    if (hb >= 6) { log('[HB 90s] Se filho ainda não logou nada, provavelmente: (1) Token errado, (2) npm install falhou, (3) crash logo no topo.'); clearInterval(heart); }
  } catch(_) {}
}, 15000);
try { heart.unref && heart.unref(); } catch(_){}
